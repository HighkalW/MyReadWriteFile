package com.example.myreadwritefile

data class FileModel(
    var filename: String? = null,
    var data: String? = null
)